class Inventory:
    def __init__(self, inventory_id, location, stock):
        self.inventory_id = inventory_id
        self.location = location
        self.stock = stock
    def withdraw_stock(self):
        pass
    def add_stock(stock):
        pass