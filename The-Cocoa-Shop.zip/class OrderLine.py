class OrderLine:
    def __init__(self, product, product_qty):
        self.product = product
        self.product_qty = product_qty
    
    def increase_qty(self):
        pass
    def decrease_qty(self):
        pass
    def total_line(self):
        pass