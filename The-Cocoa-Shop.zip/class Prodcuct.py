class Prodcuct:
    def __init__(self, product_id, product_name, product_price, product_cost, wholsale_avalible, product_category, shelf_life_days):
        self.product_id = product_id
        self.product_name = product_name
        self.product_price = product_price
        self.product_cost = product_cost
        self.wholsale_avalible = wholsale_avalible
        self.product_category = product_category
        self.shelf_life_days = shelf_life_days
    
    def calculate_profit(self):
        pass
    def get_product_info(self):
        pass
    def check_shelf_life(self):
        pass