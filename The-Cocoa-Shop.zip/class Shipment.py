class Shipment:
    def __init__(self, tracking_id):
        self.tracking_id = tracking_id
        
    def get_tracking_info(self):
        pass